#!/usr/bin/env python3
import argparse
import hashlib
import os
import platform
import socket
import sys
from datetime import datetime, timezone
from pathlib import Path

ALGORITHMS = [
    "md5",
    "sha1",
    "sha224",
    "sha256",
    "sha384",
    "sha512",
    "sha3_224",
    "sha3_256",
    "sha3_384",
    "sha3_512",
]

CHUNK_SIZE = 8 * 1024 * 1024  # 8 MiB

def hashes_for_file(path: Path):
    digesters = {name: hashlib.new(name) for name in ALGORITHMS}

    # BLAKE2 is included as an additional modern hash.
    digesters["blake2b-512"] = hashlib.blake2b(digest_size=64)

    with path.open("rb") as f:
        while True:
            block = f.read(CHUNK_SIZE)
            if not block:
                break
            for h in digesters.values():
                h.update(block)

    return {name: h.hexdigest() for name, h in digesters.items()}

def iso_utc_from_epoch(epoch):
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat().replace("+00:00", "Z")

def main():
    parser = argparse.ArgumentParser(
        description="Generate a multi-hash archival manifest for a file."
    )
    parser.add_argument("input_file", help="File to hash")
    parser.add_argument(
        "-o", "--output",
        help="Output manifest filename. Default: INPUT.archive-manifest.txt"
    )
    args = parser.parse_args()

    path = Path(args.input_file).expanduser().resolve()

    if not path.is_file():
        print(f"Error: not a regular file: {path}", file=sys.stderr)
        sys.exit(1)

    output = Path(args.output) if args.output else Path(str(path) + ".archive-manifest.txt")

    st = path.stat()
    generated_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    hashes = hashes_for_file(path)

    manifest = [
        "ARCHIVAL FILE INTEGRITY MANIFEST",
        "=" * 40,
        f"Manifest format: 1.0",
        f"Generated UTC: {generated_at}",
        f"Generator: archive-hashes.py",
        f"Python: {platform.python_version()}",
        f"Hostname: {socket.gethostname()}",
        "",
        "FILE METADATA",
        "-" * 40,
        f"Original path: {path}",
        f"Filename: {path.name}",
        f"Size bytes: {st.st_size}",
        f"Modified UTC: {iso_utc_from_epoch(st.st_mtime)}",
        f"File mode (octal): {oct(st.st_mode & 0o777)}",
        "",
        "DIGESTS",
        "-" * 40,
    ]

    for algorithm, digest in hashes.items():
        manifest.append(f"{algorithm.upper():<12} {digest}  {path.name}")

    manifest.extend([
        "",
        "VERIFICATION NOTES",
        "-" * 40,
        "For archival integrity verification, prefer SHA256, SHA512,",
        "SHA3-256/SHA3-512, or BLAKE2B-512.",
        "MD5 and SHA1 are included only for legacy compatibility and",
        "should not be used alone for collision-resistant verification.",
        "",
    ])

    output.write_text("\n".join(manifest), encoding="utf-8")
    print(f"Created: {output}")

if __name__ == "__main__":
    main()
