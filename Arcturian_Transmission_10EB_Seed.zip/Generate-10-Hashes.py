#!/usr/bin/env python3
# generate_10_hashes.py — AnthroHeart GOOD FILES v2 — 10 HASHES for Internet Archive
# Works with spaces and ! in path, no sudo
import hashlib, pathlib, sys, zlib, os

zip_path = pathlib.Path("out_archive.zip")
if not zip_path.exists():
    # try out_archive/out_archive.zip ? 
    alt = pathlib.Path("out_archive") / "out_archive.zip"
    if alt.exists():
        zip_path = alt
    else:
        print(f"❌ {zip_path} not found. Run bash ./Compile.sh --testrun first")
        print("Looking for any out_archive.zip...")
        for p in pathlib.Path(".").rglob("out_archive.zip"):
            print(f"  found {p}")
        sys.exit(1)

print(f"🦊 Generating 10 HASHES for {zip_path} ({zip_path.stat().st_size} bytes)")

data = zip_path.read_bytes()

# 10 hashes
hashes = {}
hashes["MD5"] = hashlib.md5(data).hexdigest()
hashes["SHA1"] = hashlib.sha1(data).hexdigest()
hashes["SHA224"] = hashlib.sha224(data).hexdigest()
hashes["SHA256"] = hashlib.sha256(data).hexdigest()
hashes["SHA384"] = hashlib.sha384(data).hexdigest()
hashes["SHA512"] = hashlib.sha512(data).hexdigest()
hashes["SHA3-256"] = hashlib.sha3_256(data).hexdigest()
hashes["SHA3-512"] = hashlib.sha3_512(data).hexdigest()
# BLAKE2b-256 and BLAKE2b-512
hashes["BLAKE2b-256"] = hashlib.blake2b(data, digest_size=32).hexdigest()
hashes["BLAKE2b-512"] = hashlib.blake2b(data).hexdigest()
# extra: CRC32 as 10th alternative if you count MD5 as 1, but we have 10 now
# We'll keep CRC32 as bonus 11th for Internet Archive
crc = format(zlib.crc32(data) & 0xFFFFFFFF, '08x')
hashes["CRC32"] = crc

# Write HASHES.txt
out_txt = pathlib.Path("HASHES.txt")
# Also Internet Archive naming: out_archive.zip.HASHES.txt ?
with out_txt.open("w") as f:
    f.write(f"AnthroHeart Future Archive — {zip_path} — 10 HASHES — GOOD FILES v2\n")
    f.write(f"File: {zip_path} Size: {len(data)} bytes\n")
    f.write(f"Generated: via generate_10_hashes.py — Love Is Friends\n")
    f.write("="*80 + "\n")
    for name in ["MD5","SHA1","SHA224","SHA256","SHA384","SHA512","SHA3-256","SHA3-512","BLAKE2b-256","BLAKE2b-512","CRC32"]:
        f.write(f"{name:15} {hashes[name]}\n")
    f.write("="*80 + "\n")

print(out_txt.read_text())

# Also write individual .hash files for Internet Archive auto-verify
for name, val in hashes.items():
    ext = name.lower().replace("-","")
    # e.g. out_archive.zip.sha256
    sidecar = pathlib.Path(f"{zip_path}.{ext}")
    sidecar.write_text(f"{val}  {zip_path.name}\n")
    print(f"✅ {sidecar}")

print(f"\n✅ Done — 10 HASHES in {out_txt} + sidecars for Internet Archive")
print("Upload to Internet Archive:")
print(f"  ia upload anthroheart-future-archive-{hashes['SHA256'][:8]} {zip_path} {out_txt} --metadata=\"title:AnthroHeart Future Archive GOOD FILES v2\" --metadata=\"mediatype:software\"")
